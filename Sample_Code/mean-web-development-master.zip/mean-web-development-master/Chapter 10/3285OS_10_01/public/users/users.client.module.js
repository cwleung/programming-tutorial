// Invoke 'strict' JavaScript mode
'use strict';

// Create the 'users' module
angular.module('users', []);
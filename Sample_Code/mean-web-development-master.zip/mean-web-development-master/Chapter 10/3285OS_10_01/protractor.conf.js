// Invoke 'strict' JavaScript mode
'use strict';

// Define the Protractor configuration
exports.config = {
	specs: ['public/*[!lib]*/tests/e2e/*.js']
}
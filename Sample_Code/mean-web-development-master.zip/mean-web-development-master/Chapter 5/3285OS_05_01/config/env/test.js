// Invoke 'strict' JavaScript mode
'use strict';

// Set the 'test' environment configuration object
module.exports = {
	db: 'mongodb://localhost/mean-test',
	sessionSecret: 'testSessionSecret'
};